"use strict";

const expressionDisplay = document.querySelector("#expression");
const resultDisplay = document.querySelector("#result");
const resultLabel = document.querySelector("#result-label");
const errorDisplay = document.querySelector("#error-message");
const keypad = document.querySelector(".keypad");

let expression = "";
let justEvaluated = false;

const displayExpression = () => {
  expressionDisplay.textContent = expression || "0";
};

function showError(message) {
  errorDisplay.textContent = message;
  resultDisplay.textContent = "—";
  resultLabel.textContent = "ERROR";
}

function clearError() {
  errorDisplay.textContent = "";
  resultLabel.textContent = "RESULT";
}

function formatNumber(number) {
  if (!Number.isFinite(number)) throw new Error("Result is outside the supported range.");
  const rounded = Number.parseFloat(number.toPrecision(12));
  return Object.is(rounded, -0) ? "0" : String(rounded);
}

// Recursive-descent parser: supports decimals, parentheses, unary signs, and operator precedence.
function evaluate(source) {
  const input = source.replaceAll("×", "*").replaceAll("÷", "/").replaceAll("−", "-").replace(/\s+/g, "");
  let position = 0;

  function parseExpression() {
    let value = parseTerm();
    while (input[position] === "+" || input[position] === "-") {
      const operator = input[position++];
      const right = parseTerm();
      value = operator === "+" ? value + right : value - right;
    }
    return value;
  }

  function parseTerm() {
    let value = parseUnary();
    while (["*", "/", "%"].includes(input[position])) {
      const operator = input[position++];
      const right = parseUnary();
      if ((operator === "/" || operator === "%") && right === 0) {
        throw new Error(operator === "/" ? "Cannot divide by zero." : "Cannot find a remainder with zero.");
      }
      if (operator === "*") value *= right;
      if (operator === "/") value /= right;
      if (operator === "%") value %= right;
    }
    return value;
  }

  function parseUnary() {
    if (input[position] === "+") { position++; return parseUnary(); }
    if (input[position] === "-") { position++; return -parseUnary(); }
    return parsePrimary();
  }

  function parsePrimary() {
    if (input[position] === "(") {
      position++;
      const value = parseExpression();
      if (input[position] !== ")") throw new Error("Missing closing parenthesis.");
      position++;
      return value;
    }

    const start = position;
    let decimalSeen = false;
    while (position < input.length) {
      const char = input[position];
      if (char >= "0" && char <= "9") { position++; continue; }
      if (char === "." && !decimalSeen) { decimalSeen = true; position++; continue; }
      break;
    }
    const token = input.slice(start, position);
    if (!token || token === ".") throw new Error("Enter a valid number.");
    const value = Number(token);
    if (!Number.isFinite(value)) throw new Error("Enter a valid number.");
    return value;
  }

  if (!input) throw new Error("Enter an expression first.");
  const value = parseExpression();
  if (position < input.length) {
    if (input[position] === ")") throw new Error("There is an extra closing parenthesis.");
    throw new Error("Check the expression and try again.");
  }
  return value;
}

function updatePreview() {
  clearError();
  displayExpression();
  if (!expression) {
    resultDisplay.textContent = "0";
    return;
  }
  try {
    resultDisplay.textContent = formatNumber(evaluate(expression));
  } catch {
    // Partial input is normal while typing; show guidance only when equals is pressed.
    resultDisplay.textContent = "…";
  }
}

function appendValue(value) {
  if (justEvaluated && /[0-9.]/.test(value)) expression = "";
  justEvaluated = false;

  if (value === ".") {
    const currentNumber = expression.split(/[+−×÷%]/).pop().split(/[()]/).pop();
    if (currentNumber.includes(".")) return;
    if (!currentNumber) expression += "0";
  }

  if (/^[+−×÷%]$/.test(value)) {
    if (!expression && value !== "−") return;
    if (/[+−×÷%]$/.test(expression)) {
      if (value === "−" && /[×÷%]$/.test(expression)) expression += value;
      else expression = expression.slice(0, -1) + value;
      updatePreview();
      return;
    }
  }

  expression += value;
  updatePreview();
}

function calculate() {
  clearError();
  displayExpression();
  try {
    const answer = formatNumber(evaluate(expression));
    expression = answer;
    expressionDisplay.textContent = answer;
    resultDisplay.textContent = answer;
    justEvaluated = true;
  } catch (error) {
    showError(error.message);
    justEvaluated = false;
  }
}

function clearAll() {
  expression = "";
  justEvaluated = false;
  clearError();
  expressionDisplay.textContent = "0";
  resultDisplay.textContent = "0";
}

function backspace() {
  if (justEvaluated) { clearAll(); return; }
  expression = expression.slice(0, -1);
  updatePreview();
}

function toggleSign() {
  if (!expression) { appendValue("−"); return; }
  // Toggle the sign of the current numeric entry, preserving earlier operations.
  const match = expression.match(/(\d*\.?\d*)$/);
  const token = match?.[0] ?? "";
  if (!token) { appendValue("−"); return; }
  const start = expression.length - token.length;
  const preceding = expression[start - 1];
  if (preceding === "−" && (start < 2 || /[+−×÷%(]/.test(expression[start - 2]))) {
    expression = expression.slice(0, start - 1) + token;
  } else {
    expression = expression.slice(0, start) + "−" + token;
  }
  justEvaluated = false;
  updatePreview();
}

keypad.addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const { action, value } = button.dataset;
  if (action === "clear") clearAll();
  else if (action === "backspace") backspace();
  else if (action === "equals") calculate();
  else if (action === "sign") toggleSign();
  else if (value) appendValue(value);
});

document.addEventListener("keydown", (event) => {
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  const key = event.key;
  if (/^[0-9.]$/.test(key)) { appendValue(key); event.preventDefault(); return; }
  const operators = { "+": "+", "-": "−", "*": "×", "/": "÷", "%": "%", "(": "(", ")": ")" };
  if (operators[key]) { appendValue(operators[key]); event.preventDefault(); return; }
  if (key === "Enter" || key === "=") { calculate(); event.preventDefault(); return; }
  if (key === "Backspace") { backspace(); event.preventDefault(); return; }
  if (key === "Escape" || key === "Delete") { clearAll(); event.preventDefault(); }
});

updatePreview();
