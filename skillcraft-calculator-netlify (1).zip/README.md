# SkillCraft Technology Calculator

A responsive calculator built with semantic HTML, CSS, and vanilla JavaScript. It supports addition, subtraction, multiplication, division, remainder, decimal numbers, parentheses, unary signs, live result previews, clear, backspace, and keyboard input. Arithmetic is parsed safely with a recursive-descent parser; the project does not use `eval`.

## Run it

1. Open `index.html` in a modern browser.
2. Or, for a local server, open a terminal in this folder and run `python -m http.server 8000`, then visit `http://localhost:8000`.

No dependencies or build step are required. The font is loaded from Google Fonts when internet access is available, with local system font fallbacks.

## Keyboard shortcuts

- `0`–`9` and `.` enter numbers.
- `+`, `-`, `*`, `/`, and `%` enter operators.
- `(` and `)` enter parentheses.
- `Enter` or `=` calculates.
- `Backspace` deletes the last character.
- `Escape` or `Delete` clears the calculator.
